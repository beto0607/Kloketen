<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$mision = filter_input(INPUT_POST, "mision");
if(! $mision){$mision = 1;}

mysql_connect("localhost","root","asd45asd");
mysql_select_db("MisionTrivia");

$pregunta = mysql_query("SELECT t.idTrivia, t.pregunta FROM Trivia t WHERE Mision_idMision=$mision AND dificultad=1;");
$facil= array();
while($arr = mysql_fetch_array($pregunta,MYSQL_BOTH)){
    $sql = "SELECT idRespuesta, texto, correcta FROM Respuesta WHERE Trivia_idTrivia=".$arr['idTrivia'];
    $result = mysql_query($sql);
    $aux = array();
    while ($ar2 = mysql_fetch_array($result,MYSQL_BOTH)){
        array_push($aux, array($ar2["texto"],$ar2["correcta"]));
    }
    array_push($facil, array($arr["pregunta"],$aux));
}

$pregunta = mysql_query("SELECT t.idTrivia, t.pregunta FROM Trivia t WHERE Mision_idMision=$mision AND dificultad=2;");
$medio= array();
while($arr = mysql_fetch_array($pregunta,MYSQL_BOTH)){
    $sql = "SELECT idRespuesta, texto, correcta FROM Respuesta WHERE Trivia_idTrivia=".$arr['idTrivia'];
    $result = mysql_query($sql);
    $aux = array();
    while ($ar2 = mysql_fetch_array($result,MYSQL_BOTH)){
        array_push($aux, array($ar2["texto"],$ar2["correcta"]));
    }
    array_push($medio, array($arr["pregunta"],$aux));
}

$pregunta = mysql_query("SELECT t.idTrivia, t.pregunta FROM Trivia t WHERE Mision_idMision=$mision AND dificultad=3;");
$dificil= array();
while($arr = mysql_fetch_array($pregunta,MYSQL_BOTH)){
    $sql = "SELECT idRespuesta, texto, correcta FROM Respuesta WHERE Trivia_idTrivia=".$arr['idTrivia'];
    $result = mysql_query($sql);
    $aux = array();
    while ($ar2 = mysql_fetch_array($result,MYSQL_BOTH)){
        array_push($aux, array($ar2["texto"],$ar2["correcta"]));
    }
    array_push($dificil, array($arr["pregunta"],$aux));
}
